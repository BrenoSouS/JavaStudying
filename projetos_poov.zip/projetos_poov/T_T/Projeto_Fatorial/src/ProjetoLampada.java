public class ProjetoLampada {
    
}
