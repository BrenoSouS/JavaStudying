import java.util.Random;
import java.util.Scanner;

/*a) Criar um vetor de tamanho 20 de inteiros
b) Preencher os 10 primeiros valores do vetor com números digitados pelo usuário via teclado
c) Preencher os 10 últimos valores do vetor com números aleatórios entre 1 e 100
d) Mostrar o vetor inteiro na tela
e) Mostrar o vetor de trás para frente na tela
f) Calcular e mostrar a média dos valores do vetor
g) Encontrar e mostrar o maior valor e o menor valor do vetor 
h) Mostrar os valores das posições pares do vetor
i) Mostrar os valores das posições ímpares do vetor
j) Mostrar os valores pares do vetor
k) Mostrar os valores ímpares do vetor
l)Verificar se há elementos repetidos no vetor e exibir uma mensagem em caso afirmativo
m) Solicitar um valor ao usuário e verificar se esse valor existe no vetor. Se existir exibir a posição em que ele está, senão exibir uma mensagem de valor não encontrado 
n) Verificar se o vetor está em ordem crescente, ou seja, se a[0] <= a[1] <= a[2] <= ... para todos elementos do vetor  */


public class Exercicio8 {
    public static void main(String[] args) {
        int valores[] = new int[20];
        Random num = new Random();
        Scanner s = new Scanner(System.in);
        
        for(int i = 0 ; i < 10 ; i++){
            System.out.printf("Escreva um numero para a posição %d: " , i);
            valores[i] = s.nextInt();
        }

        s.close();

        for(int i = 10 ; i < 20 ; i++){
            int a = num.nextInt(100)+1;

            valores[i] = a;
        }

        for (int i : valores) {
            if(i != valores[19]){
                System.out.printf("%d -> " , i);
            }else{
                System.out.printf("%d" , i);
            }
        }

        System.out.println("\n");
        int valores_inversos[] = new int[20];
        int j = 19;

        for (int i : valores) {
            valores_inversos[j] = i;
            j--;
        }

        for (int i : valores_inversos) {
            if(i != valores_inversos[19]){
                System.out.printf("%d -> " , i);
            }else{
                System.out.printf("%d" , i);
            }
        }
        System.out.println("\n");

        j = 0;
        for (int i : valores_inversos) {
            j += i;
        }

        System.out.printf("Média dos valores do vetor: %d\n" , j/20);

        j = valores[0];

        for (int i : valores) {
            if(i > j){
                j = i;
            }
        }

        System.out.printf("\nO maior valor no vetor é: %d\n" , j);

        j = valores[0];

        for (int i : valores) {
            if(i < j){
                j = i;
            }
        }

        System.out.printf("\nO menor valor no vetor é: %d\n" , j);

        System.out.println("Valores em posição par:\n");
        for(int i = 0 ; i < 20 ; i++) {
            
            if((i % 2) == 0 ){
                System.out.print(valores[i] + " -> ");
            }
        }

        System.out.println("\nValores em posição impar:\n");
        for(int i = 0 ; i < 20 ; i++) {
            
            if((i % 2) != 0 ){
                System.out.print(valores[i] + " -> ");
            }
        }
        System.out.println("\n");

        System.out.println("Valores pares:\n");
        for (int i : valores_inversos) {
            if(i % 2 == 0){
                System.out.printf("%d -> " , i);
            }
        }

        System.out.println("\nValores impares:\n");
        for (int i : valores_inversos) {
            if(i % 2 != 0){
                System.out.printf("%d -> " , i);
            }
        }

    }
}
