import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Exercicio9 {
    public static void main(String[] args) {
        /**a) Criar um vetor de tamanho 20 de inteiros
b) Preencher os 10 primeiros valores do vetor com números digitados pelo usuário via teclado
c) Preencher os 10 últimos valores do vetor com números aleatórios entre 1 e 100
d) Mostrar o vetor inteiro na tela
e) Mostrar o vetor de trás para frente na tela
f) Calcular e mostrar a média dos valores do vetor
g) Encontrar e mostrar o maior valor e o menor valor do vetor 
h) Mostrar os valores das posições pares do vetor
i) Mostrar os valores das posições ímpares do vetor
j) Mostrar os valores pares do vetor
k) Mostrar os valores ímpares do vetor
l)Verificar se há elementos repetidos no vetor e exibir uma mensagem em caso afirmativo
m) Solicitar um valor ao usuário e verificar se esse valor existe no vetor. Se existir exibir a posição em que ele está, senão exibir uma mensagem de valor não encontrado 
n) Verificar se o vetor está em ordem crescente, ou seja, se a[0] <= a[1] <= a[2] <= ... para todos elementos do vetor  */
 

        ArrayList<Integer> valores = new ArrayList<>();

        Scanner s = new Scanner(System.in);
        for (int i = 0 ; i < 10 ; i++){
            System.out.printf("digite valores [%d] :" , i);
            valores.add(s.nextInt());
        }

        
        for (int i = 0 ; i < 10 ; i++){
            Random numrandom = new Random();
            valores.add(numrandom.nextInt(1, 101));
        }

       System.out.println(valores);

        System.out.println("\n");

        for(int i = 19 ; i > 0 ; i--){
            System.out.printf("%d ->" , valores.get(i));
        }

        int soma = 0;
        for (int integer : valores) {
            soma += integer;
        }
        System.out.println("\n######################################################");
        System.out.printf(" \n\tmédia dos valores do ArrayList : %d\n" , soma/valores.size());

        System.out.println("\n######################################################");

        int j = valores.get(0);

        for (int i : valores) {
            if(i > j){
                j = i;
            }
            
        }

        System.out.printf(" \n\tmaior valor do ArrayList : %d\n" , j);

        System.out.println("\n######################################################");

        j = valores.get(0);

        for (int i : valores) {
            if(i < j){
                j = i;
            }
            
        }

        System.out.printf(" \n\t menor valor do ArrayList : %d\n" , j);

        System.out.println("\n######################################################");

        s.close();
    }
}
