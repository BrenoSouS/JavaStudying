
import java.util.Scanner;

public class App {

    public static void main(String[] args) throws Exception {

        // TESTE DOS PALINDROMOS
        Scanner s = new Scanner(System.in);
        System.out.println("Digite uma palavra: ");
        String nova = s.nextLine();

        StringBuilder stringModificada = new StringBuilder(nova.replace(" ", ""));
        stringModificada = stringModificada.reverse();

        String saidaReversa = stringModificada.toString();

        if (nova.replace(" ", "").equalsIgnoreCase(saidaReversa)) {
            System.out.printf("A Palavra/frase   \"%s\" ,é um pálidromo!", nova);
        } else {
            System.out.printf("A Palavra/frase   \"%s\" ,não é um pálidromo!\n", nova);
        }
        
        s.close();
    }
}
