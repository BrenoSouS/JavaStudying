import java.util.ArrayList;
import java.util.Random;

public class ARRAY {
    public static void main(String[] args) {
        Random numero_aleatorio = new Random();
        
        ArrayList<Integer> array_inteiros = new ArrayList<>();

        for(int i = 0 ; i < 10 ; i++){
            int a  = numero_aleatorio.nextInt(999);
            array_inteiros.add(a);
        }

        for (Integer b : array_inteiros) {
            System.out.printf("%d " , b);
        }
        System.out.println("\n");
    }
}
