import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.MonthDay;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;
import java.time.DayOfWeek;
import java.time.Duration;

public class DATA {
    public static void main(String[] args) {
        Instant agora = Instant.now();

        // System.out.println(agora);

        // System.out.println(Instant.EPOCH);
        // System.out.println(Instant.MAX);
        // System.out.println(Instant.MIN);
        // /################################################################################
        // LocalDate hoje = LocalDate.now();
        // System.out.println(hoje);

        // LocalDate especifico = LocalDate.of(2003, 10, 30);
        // System.out.println(especifico);

        // LocalDate especifico2 = LocalDate.of(2003, Month.OCTOBER, 30);
        // System.out.println(especifico2);

        // ################################################################################

        // Instant inicio = Instant.now();
        // for (int cont = 0; cont < 1000; cont++) {
        // System.out.println("Nada");
        // }
        // Instant fim = Instant.now();

        // Duration duracao = Duration.between(inicio, fim);

        // System.out.println("Em segundos: " + duracao.getSeconds());
        // System.out.println("Nanosegundos do último segundo: " + duracao.getNano());
        // System.out.println("Em milisegundos: " + duracao.toMillis());

        // LocalDate homemNoEspaco = LocalDate.of(1961, Month.APRIL, 12);
        // LocalDate homemNaLua = LocalDate.of(2026, Month.AUGUST, 13);

        // Period periodo = Period.between(homemNoEspaco, homemNaLua);

        // System.out.printf("O home foi para a lua á exatos : %s ano(s), %s mes(es) e
        // %s dia(s)\n", periodo.getYears(),
        // periodo.getMonths(),
        // periodo.getDays());
        // // 8 ano(s), 1 mes(es) e 13 dia(s)
        // //
        // ################################################################################

        // LocalTime agoraa = LocalTime.now();
        // System.out.println(agoraa); // 16:18:49.666

        // LocalTime horarioDeEntrada = LocalTime.of(18, 45);
        // System.out.println(horarioDeEntrada); // 18:45

        // //
        // ################################################################################

        // LocalDateTime ldtAgora = LocalDateTime.now();
        // System.out.println(ldtAgora); // 2015-02-25T21:18:08.491

        // LocalDateTime inicioSemestre = LocalDateTime.of(2015, Month.FEBRUARY, 4, 18,
        // 45);
        // System.out.println(inicioSemestre); // 2015-02-04T18:45

        // //
        // ################################################################################

        // System.out.println(ZoneId.getAvailableZoneIds().size()); // 604
        // System.out.println(ZoneId.getAvailableZoneIds());

        ZoneId fusoHorarioDeSaoPaulo = ZoneId.of("America/Sao_Paulo");
        ZoneId fusoHorarioDeNewYork = ZoneId.of("America/New_York");

        // ################################################################################
        // ZonedDateTime agoraEmSaoPaulo = ZonedDateTime.now(fusoHorarioDeSaoPaulo);
        // System.out.println(agoraEmSaoPaulo);
        // ZonedDateTime agoraEmNewYork = ZonedDateTime.now(fusoHorarioDeNewYork);
        // System.out.println(agoraEmNewYork);

        // ################################################################################
        // LocalDateTime saidaDeSaoPauloSemFusoHorario = LocalDateTime.of(2014,
        // Month.APRIL, 4, 22, 30);
        // LocalDateTime chegadaEmNovaYorkSemFusoHorario = LocalDateTime.of(2014,
        // Month.APRIL, 5, 7, 10);

        // Duration duracaoVooSemFusoHorario =
        // Duration.between(saidaDeSaoPauloSemFusoHorario,
        // chegadaEmNovaYorkSemFusoHorario);
        // System.out.println(duracaoVooSemFusoHorario); // PT8H40M

        // //
        // ################################################################################
        // ZonedDateTime saidaDeSaoPauloComFusoHorario =
        // ZonedDateTime.of(saidaDeSaoPauloSemFusoHorario,
        // fusoHorarioDeSaoPaulo);

        // ZonedDateTime chegadaEmNovaYorkComFusoHorario =
        // ZonedDateTime.of(chegadaEmNovaYorkSemFusoHorario,
        // fusoHorarioDeNewYork);

        // Duration duracaoVooComFusoHorario =
        // Duration.between(saidaDeSaoPauloComFusoHorario,
        // chegadaEmNovaYorkComFusoHorario);
        // System.out.println(duracaoVooComFusoHorario); // PT9H40M
        // //
        // ################################################################################

        // MonthDay natal = MonthDay.of(Month.DECEMBER, 25);
        // System.out.println(natal); // --12-25

        // MonthDay hoje = MonthDay.now();
        // System.out.println(hoje); // --04-04

        // ################################################################################
        // LocalDate ldHoje = LocalDate.now();
        // System.out.println(ldHoje); // 2015-02-25

        // DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        // System.out.println(ldHoje.format(formatador)); // 25/02/2015
        // ################################################################################
        // String texto;
        // LocalDate data;
        // Scanner s = new Scanner(System.in);
        // DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        // System.out.print("Digite a data dd/mm/aaaa: ");
        // texto = s.nextLine();
        // data = LocalDate.parse(texto, formatador);
        // System.out.println(data);
        // s.close();
        // //
        // ################################################################################
        Locale brasil = Locale.of("pt", "BR");

        Locale local = Locale.of(System.getProperty("user.language"), System.getProperty("user.country"));

        System.out.println(brasil);
        System.out.println(local);
        // ################################################################################
        // ZonedDateTime zdtHoje = ZonedDateTime.now();
        // DateTimeFormatter formatador;
        // formatador =
        // DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).withLocale(Locale.FRANCE);
        // System.out.println(zdtHoje.format(formatador));
        // formatador =
        // DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).withLocale(Locale.ITALY);
        // System.out.println(zdtHoje.format(formatador));
        // formatador =
        // DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).withLocale(Locale.JAPAN);
        // System.out.println(zdtHoje.format(formatador));
        // formatador =
        // DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).withLocale(Locale.GERMANY);
        // System.out.println(zdtHoje.format(formatador));
        // formatador =
        // DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).withLocale(Locale.KOREA);
        // System.out.println(zdtHoje.format(formatador));
        // formatador =
        // DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).withLocale(Locale.of("pt",
        // "BR"));
        // System.out.println(zdtHoje.format(formatador));

        // ################################################################################
        // Period periodo = Period.of(2, 3, 10);
        // LocalDate hoje = LocalDate.now();
        // System.out.println(hoje);
        // LocalDate amanha = hoje.plusDays(1);
        // System.out.println(amanha);
        // LocalDate daqui3Semanas = hoje.plusWeeks(3);
        // System.out.println(daqui3Semanas);
        // LocalDate daqui3Meses = hoje.plusMonths(3);
        // System.out.println(daqui3Meses);
        // LocalDate daqui3Anos = hoje.plusYears(3);
        // System.out.println(daqui3Anos);
        // LocalDate daqui2Anos3Meses10Dias = hoje.plus(periodo);
        // System.out.println(daqui2Anos3Meses10Dias);

        // ################################################################################
        // LocalDate ontem = hoje.minusDays(1);
        // LocalDate tresSemanasAtras = hoje.minusWeeks(3);
        // LocalDate tresMesesAtras = hoje.minusMonths(3);
        // LocalDate tresAnosAtras = hoje.minusYears(3);
        // LocalDate doisAnos3Meses10DiasAtras = hoje.minus(periodo);

        // LocalDate dia10MesAtual = hoje.withDayOfMonth(10);
        // LocalDate diaHojeMesAbril = hoje.withMonth(4);
        // LocalDate diaHojeMesAbril2 = hoje.withMonth(Month.APRIL.getValue());
        // // LocalDate diaHojeAno2014 = hoje.withYear(2014);
        // // ################################################################################
        // LocalDate hoje = LocalDate.now();
        // int dia = hoje.getDayOfMonth();
        // System.out.println(dia);
        // int mes = hoje.getMonthValue();
        // System.out.println(mes);
        // int ano = hoje.getYear();
        // System.out.println(ano);
        // int diaSemana = hoje.getDayOfWeek().getValue();
        // System.out.println(diaSemana);
        // String textoDiaSemana = hoje.getDayOfWeek()
        //         .getDisplayName(TextStyle.FULL, Locale.of("pt", "br"));
        // System.out.println(textoDiaSemana);
        // textoDiaSemana = hoje.getDayOfWeek()
        //         .getDisplayName(TextStyle.FULL, Locale.JAPAN);
        // System.out.println(textoDiaSemana);
        // // ################################################################################

        // int tamanhoMes = hoje.lengthOfMonth();
        // System.out.println(tamanhoMes);
        // int tamanhoAno = hoje.lengthOfYear();
        // System.out.println(tamanhoAno);
        // if (hoje.isLeapYear()) {
        //     System.out.println("Ano Bissexto");
        // } else {
        //     System.out.println("Ano Não Bissexto");
        // }
        // // ################################################################################

        // TemporalAdjuster primeiroDiaMesTA = TemporalAdjusters.firstDayOfMonth();
        // TemporalAdjuster primeiroDiaProximoMesTA = TemporalAdjusters.firstDayOfNextMonth();
        // TemporalAdjuster primeiroDiaProximoAnoTA = TemporalAdjusters.firstDayOfNextYear();
        // TemporalAdjuster primeiroDiaAnoTA = TemporalAdjusters.firstDayOfYear();
        // TemporalAdjuster primeira2aDoMesTA = TemporalAdjusters.firstInMonth(DayOfWeek.MONDAY);
        // TemporalAdjuster ultimoDiaMesTA = TemporalAdjusters.lastDayOfMonth();
        // TemporalAdjuster ultimoDiaAnoTA = TemporalAdjusters.lastDayOfYear();
        // TemporalAdjuster ultima2aDoMesTA = TemporalAdjusters.lastInMonth(DayOfWeek.MONDAY);
        // TemporalAdjuster proxima2aTA = TemporalAdjusters.next(DayOfWeek.MONDAY);
        // TemporalAdjuster proximaOuAtual2aTA = TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY);
        // TemporalAdjuster segundaAnteriorTA = TemporalAdjusters.previous(DayOfWeek.MONDAY);
        // TemporalAdjuster segundaAnteriorOuAtualTA = TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY);
        // TemporalAdjuster terceira5aDoMesTA = TemporalAdjusters.dayOfWeekInMonth(3, DayOfWeek.THURSDAY);

        // LocalDate hoje = LocalDate.now();
        // LocalDate proxima2a = hoje.with(proxima2aTA);
        // System.out.println(proxima2a);
        // LocalDate ultima2aMes = hoje.with(ultima2aDoMesTA);
        // System.out.println(ultima2aMes);
        // LocalDate terceira5aDoMes = hoje.with(terceira5aDoMesTA);
        // System.out.println(terceira5aDoMes);
        // ################################################################################

        // ################################################################################

        String data;
        LocalDate objdata;
        LocalDate HOJE = LocalDate.now();
        
        Scanner s = new Scanner(System.in);
        
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.print("Digite a sua data de nascimento no formato dd/mm/aaaa: ");
        data = s.nextLine();
        objdata = LocalDate.parse(data, formatador);
        System.out.println(data);
        
        DayOfWeek DIA_usuario = objdata.getDayOfWeek();
        String textoDia  =  DIA_usuario.getDisplayName(TextStyle.FULL , Locale.of("pt" , "BR"));
        
        System.out.println("Dia da semana: " + textoDia);
        
        Period periodo = Period.between(objdata, HOJE);

        System.out.println("Desde seu nascimento se passaram: " + periodo.getYears() + " Anos , " +  periodo.getMonths() + " Meses e " + periodo.getDays() + " Dias.");
        System.out.println("fazem "+ objdata.until(HOJE, ChronoUnit.DAYS) + " Dias , desde então.");
        s.close();

    }
}
