import java.util.Scanner;

public class As {

    public static int nova(){
        Scanner novo = new Scanner(System.in);
        int valor = novo.nextInt();
        for(int i = 0 ; i < 20 ; i++){
            if(i % 2 == 0 && i % 3 != 0){
                valor += i;
            }
        }
        novo.close();

        return valor;
    }
    public static void main(String[] args) {
        System.out.printf("Digite um numero inteiro: ");
        System.out.printf("\n SAIDA: %d " , nova());

    }

}
