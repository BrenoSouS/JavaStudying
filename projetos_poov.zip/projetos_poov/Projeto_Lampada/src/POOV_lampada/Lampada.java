package POOV_lampada;

public class Lampada{

    private int tensao ;
    private int potencia;
    private boolean acesa;
    private boolean queimada;
    private boolean quebrada;

    //construtores

    

    //padrao
    public Lampada(){
        System.out.println("Construtor padrão da lampada executado");
        tensao = 110;
        potencia = 60;

    }

    public Lampada(int tensao , int potencia , boolean acesa, boolean queimada , boolean quebrada){
        System.out.println("Construtor de alocação da lampada executado");
        setTensao(tensao);
        setPotencia(potencia);
        setQueimada(queimada);
        setQuebrada(quebrada);
        setAcesa(acesa);
    }

    //getters e setters

    public int getTensao() {
        return tensao;
    }

    public void setTensao(int tensao) {
        if(tensao == 110 || tensao == 220){
            this.tensao = tensao;
        }
        else{
            System.out.println("\nValor invalido de tensão.Usando valor padrão: 200\n");
            this.tensao = 220;
        }

    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        if(potencia == 60 || potencia == 90 || potencia == 100){
            this.potencia = potencia;
        }
        else{
            System.out.println("\nValor invalido de potencia.Usando valor padrão: 100\n");
            this.potencia = 100;
        }
    }

    public boolean isAcesa() {
        return acesa;
    }

    public void setAcesa(boolean acesa) {
        if(acesa){
            if(quebrada){
                queimada = true;
                this.acesa = false;
            }
            else if(!queimada){
                this.acesa = acesa;
            }
        }else{
            this.acesa = acesa;
        }
    }

    public boolean isQueimada() {
        return queimada;
    }

    public void setQueimada(boolean queimada) {
        if(queimada){
            this.queimada = true;
            this.acesa = false;
        }else{
            this.queimada = false;
        }
    }

    public boolean isQuebrada() {
        return quebrada;
    }

    public void setQuebrada(boolean quebrada) {
        if(quebrada){
            this.quebrada = true;
            if(this.acesa){

                this.acesa =false;
                this.queimada  = true;

            }
        }else{
            this.quebrada = false;
        }
    }

    public void mostrarTela(){
        System.out.printf("%d V\n" , tensao);
        System.out.printf("%d W\n" , potencia);
        System.out.printf(acesa ? "Acesa\n" : "Apagada\n");
        if(queimada){
            System.out.println("Queimada");
        }
        if(quebrada){
            System.out.println("Quebrada\n");
        }

    }


    public void acender(){
        setAcesa(true);
    }


    public void apagar(){
        setAcesa(false);
    }


    public void quebrar(){
        setQuebrada(true);
    }

    public void queimar(){
        setQueimada(true);
    }

    
}