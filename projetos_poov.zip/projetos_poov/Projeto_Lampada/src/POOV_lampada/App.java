package POOV_lampada;
public class App {
    
    
    public static void main(String[] args) {
        System.out.println("\n#######################################\n");
        Lampada l1  = new Lampada();

        l1.mostrarTela();
        System.out.println("\n#######################################\n");


        // l1.tensao = 110;
        // l1.potencia = 100;
        // l1.acesa = true;
        // l1.quebrada = false;
        // l1.queimada = false;

        l1.mostrarTela();

        System.out.println("\n#######################################\n");

        Lampada l2 = new Lampada(220, 100, false, true, false);
        Lampada l3 = new Lampada(2220, -100, false, true, false);

        l2.mostrarTela();
        System.out.println("\n#######################################\n");
        l3.mostrarTela();

        // l2.setAcesa(true);
        // System.out.println("\n#######################################\n");
        // l2.mostrarTela();

        // System.out.println("\n#######################################\n");
        // l2.setQuebrada(true);
        // l2.setAcesa(false);
        // l2.mostrarTela();

    }
}
