package POOV_lampada;

public class LampadaColorida extends Lampada{
    private String cor;

    public void setCor(String cor){
        this.cor = cor;
    }

    public String getCor(){
        return cor;
    }

    public LampadaColorida(){
        super();
        
    }

    
    @Override
    public void mostrarTela(){
        super.mostrarTela();
        System.out.println("Cor = " + cor);
    }
}
