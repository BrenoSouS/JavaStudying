import java.util.Scanner;
import java.math.BigInteger;

public class Fatorial{

    public static void main(String args []){
        Scanner s = new Scanner(System.in);
        BigInteger numero , fatorial = BigInteger.ONE;
        
        System.out.printf("Digite um número: ");
        
        numero = s.nextBigInteger();
        
        for(BigInteger i = numero ; i.compareTo(BigInteger.ONE) == 1 ; i = i.subtract(BigInteger.ONE)){
            fatorial = fatorial.multiply(i);
        }
        
        System.out.printf("Fatorial de %d é igual a %d\n" , numero , fatorial);
        
        s.close();
    }
}
