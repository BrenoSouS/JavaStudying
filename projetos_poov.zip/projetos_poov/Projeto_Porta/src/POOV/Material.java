package POOV;

public enum Material {
    MADEIRA("madeira"), AÇO ("aço"), VIDRO ("vidro"), PVC("pvc") , ALUMINIO("aluminio");

    private String texto;

    private Material(String texto){
        this.texto = texto;
    }

    public String getTexto(){
        return texto;
    }
}


