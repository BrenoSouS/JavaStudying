package POOV;

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

        Porta p1 = new Porta();
        Porta p2 = new Porta(Material.PVC, 110, false, false);
        Porta p3 = new Porta(Material.VIDRO, 90);

        p1.mostrarNaTela();
        p2.mostrarNaTela();
        p3.mostrarNaTela();

        Scanner s = new Scanner(System.in);
        // System.out.printf("Digite o material: ");

        // String str = s.nextLine();

        Material novomaterial;

        Material materiais[] = Material.values();

        int opcao;
        do {
            for (Material mat : materiais) {
                System.out.println(mat.ordinal() + " - " + mat);
            }

            System.out.printf("Digite uma Opção: ");
            opcao = Integer.parseInt(s.nextLine());
        } while (opcao < 0 && opcao > 4);

        novomaterial = materiais[opcao];

        System.out.println(novomaterial);
        System.out.println(novomaterial.getTexto());

        s.close();
    }
}
