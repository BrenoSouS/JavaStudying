package POOV;
public class Porta {
    private Material material;
    private int largura;
    private boolean fechada;
    private boolean trancada;

    // Contrutores

    public Porta() {

        material = Material.MADEIRA;
        largura = 60;
        fechada = true;
        trancada = true;

    }

    public Porta(Material material , int largura , boolean fechada , boolean trancada){
        this.material = material;
        setLargura(largura);
        setFechada(fechada);
        setTrancada(trancada);
    }

    public Porta(Material material , int largura){
        this.material = material;
        setLargura(largura);
        this.trancada = true;
        this.fechada = true;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
       
            this.material = material;

    }

    public int getLargura() {
        return largura;
    }

    public void setLargura(int largura) {
        if (largura == 60 || largura == 70 || largura == 80 || largura == 90 || largura == 100 || largura == 110
                || largura == 120) {

            this.largura = largura;
        } else {
            System.out.println("#####################################");
            System.out.println("\n\tLargura invalida!.Usando o padrão: 60\n");
            System.out.println("#####################################");
            this.largura = 60;
        }
    }

    public boolean isFechada() {
        return fechada;
    }

    private void setFechada(boolean fechada) {
        if (fechada) {
            if (!fechada && trancada) {
                System.out.println("Não da para fechar uma porta trancada");
            } else {
                fechada = true;
            }
        } else {
            if (fechada && trancada) {
                System.out.println("Não da para abrir uma porta trancada");
            } else {
                fechada = false;
            }
        }

    }

    public boolean isTrancada() {
        return trancada;
    }

    private void setTrancada(boolean trancada) {
        this.trancada = trancada;
    }

    public void mostrarNaTela(){
        System.out.println("##########################################################");
        System.out.printf(" Porta de: %s com  %d cm de largura %s e %s\n" ,material.getTexto() , largura , fechada ? "fechada" : "aberta" , trancada ? "trancada" : "destrancada" );

    }


    public void abrir(){
        setFechada(false);
    }
    public void fechar(){
        setFechada(true);
    }

    public void trancar(){
        setTrancada(true);
    }
    public void destrancar(){
        setTrancada(false);
    }
}
