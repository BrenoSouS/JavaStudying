import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Produto {
    private long codigo;
    private String nome;
    private String descricao;
    private String marca;
    private int qtd_atual;
    private int qtd_minima;
    private LocalDate dataCompra;
    private BigDecimal precoCompra;
    private BigDecimal precoVenda;


//contrutores
    
    public Produto() {
        
        codigo = -1L;
        nome = "Sem Nome";
        descricao = "NAN";
        marca = "NAN";
        qtd_atual = 0;
        qtd_minima = 0;
        dataCompra = LocalDate.now();
        precoCompra = BigDecimal.ZERO;
        precoVenda = BigDecimal.ZERO;
        
    }


    public Produto(long codigo, String nome, String descricao, String marca, int qtd_atual, int qtd_minima,

         LocalDate dataCompra, BigDecimal precoCompra, BigDecimal precoVenda) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricao = descricao;
        this.marca = marca;

        setQtd_atual(qtd_atual);
        setQtd_minima(qtd_minima);
        
        this.dataCompra = dataCompra;

        setPrecoCompra(precoCompra);
        setPrecoVenda(precoVenda);
    }


//--------------------------------------------------------------------------------------


    public long getCodigo() {
        return codigo;
    }

    public void setCodigo(long codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getQtd_atual() {
        return qtd_atual;
    }

    public void setQtd_atual(int qtd_atual) {

        if(qtd_atual >= 0 ){
            
            this.qtd_atual = qtd_atual;

        }
        else{
            System.out.println("-------------------------------");
            System.out.println("quantidade Atual invalida!");
            this.qtd_atual = 0;
        }
    }

    public int getQtd_minima() {
        return qtd_minima;
    }

    public void setQtd_minima(int qtd_minima) {

        if(qtd_minima >= 0 ){
            
            this.qtd_minima = qtd_minima;

        }
        else{
            System.out.println("-------------------------------");
            System.out.println("quantidade minima invalida!");
            this.qtd_minima = 0;
        }
    }

    public LocalDate getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(LocalDate dataCompra) {
        this.dataCompra = dataCompra;
    }

    public BigDecimal getPrecoCompra() {
        return precoCompra;
    }

    public void setPrecoCompra(BigDecimal precoCompra) {
        if(precoCompra.compareTo(BigDecimal.ZERO) >= 0){

            this.precoCompra = precoCompra;
        }
        else{
            System.out.println("Valor invalido para preço de compra");
            this.precoCompra = BigDecimal.ZERO;
        }
    }

    public BigDecimal getPrecoVenda() {
        return precoVenda;
    }

    public void setPrecoVenda(BigDecimal precoVenda) {
        if(precoVenda.compareTo(BigDecimal.ZERO) >= 0){

            this.precoVenda = precoVenda;
        }
        else{
            System.out.println("Valor invalido para preço de venda");
            this.precoVenda = BigDecimal.ZERO;
        }
    } 

    public void mostrarNaTela(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("====================================\n");
        System.out.printf("Codigo: %d\n", codigo);
        System.out.printf("Nome: %s\n", nome);
        System.out.printf("Descrição: %s\n", descricao);
        System.out.printf("Marca: %s\n", marca);
        System.out.printf("Quantidade atual: %d\n", qtd_atual);
        System.out.printf("Quantidade minima: %d\n", qtd_minima);
        System.out.println("Codigo: " + dtf.format(dataCompra));
        System.out.printf("Preço da compra: R$ %d\n", precoCompra);
        System.out.printf("Preço da venda: R$ %d\n", precoVenda);
        

    }
}