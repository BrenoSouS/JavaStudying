import java.util.Scanner;


public class Problema{

    public static void main (String args[]){
        int x , y ;        
        String a, b;
        Scanner s = new Scanner(System.in);
//FUNCIONA      
//        System.out.printf("Digite X: ");
//        x = s.nextInt();
//        System.out.printf("Digite y: ");
//        y = s.nextInt();
// FUNCIONA
//        System.out.printf("Digite A: ");
//        a = s.nextLine();
//        System.out.printf("Digite B: ");
//        b = s.nextLine();

//NÃO FUNCIONA
//        System.out.printf("Digite X: ");
//        x = s.nextInt();
//        System.out.printf("Digite A: ");
//        a = s.nextLine();

//Funciona -> Melhor Solução
            System.out.printf("Digite X: ");
            b = s.nextLine();
            x = Integer.parseInt(b); //conversor:  String -> int 
            System.out.printf("Digite A: ");
            a = s.nextLine();

    }
}
