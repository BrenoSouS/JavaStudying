import java.math.BigDecimal;
import java.time.LocalDate;

import PoovPessoa.Funcionario;
import PoovPessoa.Gerente;

public class App {
    public static void main(String[] args) throws Exception {
     Funcionario f = new Funcionario("Estrobilobaldo", "12345678909", 
            LocalDate.of(2000, 8, 27), "TI", new BigDecimal("1430.0"));

        Gerente g = new Gerente("Grosbilda", "12345678990", 
            LocalDate.of(2000, 8, 27), "TI", new BigDecimal("1430.0"),
            new BigDecimal("1000.0"));

        System.out.println(f.getPagamento());
        System.out.println(g.getPagamento());
    }
}
