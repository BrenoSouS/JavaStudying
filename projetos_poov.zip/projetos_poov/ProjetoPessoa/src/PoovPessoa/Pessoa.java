package PoovPessoa;

import java.time.LocalDate;

public class Pessoa {
    private String nome;
    private String cpf;
    private LocalDate nascimento;

    //construtores
    public Pessoa(){
        nome = "Sem nome";
        cpf = "000.000.000-00";
        nascimento = LocalDate.now();
    }

    public Pessoa(String nome , String cpf , LocalDate nascimento){
        this.nome = nome;
        this.cpf = cpf;
        this.nascimento = nascimento;
    }

    //getters e setters
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public LocalDate getNascimento() {
        return nascimento;
    }

    public void setNascimento(LocalDate nascimento) {
        this.nascimento = nascimento;
    }

}
