package PoovPessoa;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Funcionario extends Pessoa {

    private String setor;
    private BigDecimal salario;


    //construtores

    public Funcionario(){
        setor = "sem setor";
        salario = BigDecimal.ZERO;
    }

    public Funcionario(String nome, String cpf, LocalDate nascimento, String setor, BigDecimal salario) {
        super(nome, cpf, nascimento);
        this.setor = setor;
        this.salario = salario;
    }

    

    public String getSetor() {
        return setor;
    }


    public void setSetor(String setor) {
        this.setor = setor;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public BigDecimal getPagamento(){
        return salario;   
    }
}
