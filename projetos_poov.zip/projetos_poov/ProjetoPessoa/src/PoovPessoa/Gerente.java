package PoovPessoa;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Gerente extends Funcionario{
    private BigDecimal bonus;
    
    public Gerente(){
        bonus = BigDecimal.ZERO;
    }


    public Gerente(String nome, String cpf, LocalDate nascimento, String setor, BigDecimal salario, BigDecimal bonus) {
        super(nome, cpf, nascimento, setor, salario);
        this.bonus = bonus;
    }


    public BigDecimal getBonus() {
        return bonus;
    }

    public void setBonus(BigDecimal bonus) {
        this.bonus = bonus;
    }

    @Override
    public BigDecimal getPagamento(){
        return getSalario().add(bonus);
    }
}
